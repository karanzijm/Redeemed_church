<?php var_dump($numbers); ?>
@foreach($numbers as $number)
{{ $number }}
@endforeach