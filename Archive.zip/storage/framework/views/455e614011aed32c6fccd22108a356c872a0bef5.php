<?php var_dump($numbers); ?>
<?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($number); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/numbers.blade.php ENDPATH**/ ?>