            <title>Redeemed Church</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            
            
            <link rel="stylesheet" href="<?php echo e(asset('css/css/open-iconic-bootstrap.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/css/animate.css')); ?>">
            
            <link rel="stylesheet" href="<?php echo e(asset('css/css/owl.carousel.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/css/owl.theme.default.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/css/magnific-popup.css')); ?>">

            <link rel="stylesheet" href="<?php echo e(asset('css/css/aos.css')); ?>">

            <link rel="stylesheet" href="<?php echo e(asset('css/css/ionicons.min.css')); ?>">
            
            <link rel="stylesheet" href="<?php echo e(asset('css/css/flaticon.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/css/icomoon.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/css/style.css')); ?>">
            
            <link rel="stylesheet" href="<?php echo e(asset('css/css/bootstrap.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/css/jquery-ui.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/css/bootstrap-datepicker.css')); ?>">
            <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">

            
<?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/generic/header.blade.php ENDPATH**/ ?>