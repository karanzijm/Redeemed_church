<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card bg-light mt-3">
        <div class="card-header">
            Import you congregation
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('importCongregation')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" class="form-control">
                <br>
                <button class="btn btn-success">Import User Data</button>
                <a class="btn btn-warning" href="<?php echo e(route('exportCongregation')); ?>">Export User Data</a>
            </form>
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/congregation.blade.php ENDPATH**/ ?>