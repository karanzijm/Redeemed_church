<script src="<?php echo e(asset('js/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/popper.min.js')); ?>"></script>


<script src="<?php echo e(asset('js/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/jquery.stellar.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/jquery.animateNumber.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/scrollax.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('js/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/js/bootstrap-datepicker.min.js')); ?>"></script><?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/generic/footer.blade.php ENDPATH**/ ?>