<!DOCTYPE html>
<html>
<head>
    <title>Laravel 5.7 Import Export Excel to database Example - ItSolutionStuff.com</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body>
    

    <?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="card bg-light mt-3">
                <div class="card-header">
                    Laravel 5.7 Import Export Excel to database Example - ItSolutionStuff.com
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="file" class="form-control">
                        <br>
                        <button class="btn btn-success">Import User Data</button>
                        <a class="btn btn-warning" href="<?php echo e(route('export')); ?>">Export User Data</a>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
   
</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/import.blade.php ENDPATH**/ ?>