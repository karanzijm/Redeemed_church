<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">



<?php $__env->startSection('content'); ?>

<?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class=”invalid-feedback” role=”alert”>
<strong><?php echo e($message); ?></strong>
</span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="col-sm-12">

  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
</div>


<div class="container">
<form class="form-inline" method="POST" action="<?php echo e(route('filters')); ?>">
  <?php echo csrf_field(); ?>
  <div class="form-group mb-2">
    <label for="filter" class="col-sm-2 col-form-label">Show</label>
    <select class="form-control" name="paginate">
      <option value="10">10</option>
      <option value="50">50</option>
      <option value="200">200</option>
      <option value="1000">1000</option>
    </select>
  </div>
    <div class="form-group mb-2">
      <label for="filter" class="col-sm-2 col-form-label">Search</label>
      <input type="text" class="form-control" id="filter" name="filter" placeholder="name,email,contact..." value="<?php echo e($filter ?? ''); ?>">
    </div>
    <button type="submit" class="btn btn-primary mb-2">Search</button>
  </form>


  <div class="table-responsive">
      <form method="POST" action="<?php echo e(route('send')); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

        <table class="table">
          <thead>
            <tr>
              <th><input type="checkbox" class="selectAll" onclick()="selectAll()"></th>
              <th>Name</th>
              <th>Email</th>
              <th>Contact</th>
              <th>Location</th>
              <th>Home Cell</th>
              <th>Marital Status</th>
              <th>Numbersss of Children</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          <?php if($users->count() == 0): ?>
        <tr>
            <td colspan="7">No Results available.</td>
        </tr>
        <?php endif; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr id="tr_<?php echo e($user->contact); ?>">
                <td><input data-id="<?php echo e($user->contact); ?>" value="<?php echo e($user->id); ?>" class="sub_chk" type="checkbox" name="selected_values[]">
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->contact); ?></td>
                <td><?php echo e($user->location); ?></td>
                <td><?php echo e($user->home_cell); ?></td>
                <td><?php echo e($user->marital_status?$user->marital_status: 'Not Set'); ?></td>
                <td><?php echo e($user->no_of_children?$user->no_of_children: 'Not Set'); ?></td>
                <td>
                    <a href="<?php echo e(route('edit',$user->id)); ?>" class="edit btn btn-success btn-sm">Edit</a>
                    <a href="#" data-toggle="modal" data-id="<?php echo e($user->id); ?>" data-url="<?php echo URL::route('delete',$user->id); ?>" data-target="#deleteModal" class="delete btn btn-danger btn-sm">Delete</a>
                  </td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
        <button type="submit" name="submit">Here</button>
      <a href="<?php echo e(route('read')); ?>" class="btn btn-success btn-sm">Read File</a>
            </form>
            <?php echo $users->appends(Request::except('page'))->render(); ?>

            <p>
              Displaying <?php echo e($users->count()); ?> of <?php echo e($users->total()); ?> user(s).
          </p>
    </div>
</div>

              <!-- Delete Warning Modal -->
<form action="" method="POST" class="remove-record-model">
                <div id="deleteModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="deleteLabel" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog" style="width:55%;">
                        <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title" id="deleteLabel">Confirm Delete Record</h4>

                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            </div>
                            <div class="modal-body">
                                <h4>Are You Sure You want to Delete This Record?</h4>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default waves-effect remove-data-from-delete-form" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-danger waves-effect waves-light">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
      <!-- End Delete Modal -->
<?php
if(isset($_GET["submit"])){
    var_dump($_GET['selected_values']);
    $val = $_GET['selected_values'];
    echo $val[0];
}
?>
<?php $__env->stopSection(); ?>
<script>
$(document).ready(function(){
    $(".selectAll").click(function(e){
        if($(this).is(':checked', true)){
            $(".sub_chk").prop('checked',true);
        }else{
          $(".sub_chk").prop('checked',false);
        }
  });

  $('.delete').click(function (){
    var id = $(this).attr('data-id');
		var url = $(this).attr('data-url');
		var token = CSRF_TOKEN;
    $(".delete").attr("action",url);
		$('body').find('.delete').append('<input name="_token" type="hidden" value="'+ token +'">');
		$('body').find('.delete').append('<input name="_method" type="hidden" value="DELETE">');
		$('body').find('.delete').append('<input name="id" type="text" value="'+ id +'">');

  });
})

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/view.blade.php ENDPATH**/ ?>