<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('generic.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
        <main>
          <?php echo $__env->make('generic.mysidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->yieldContent('content'); ?>
        </main>
    
    </body>
    <?php echo $__env->make('generic.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/generic/myfile.blade.php ENDPATH**/ ?>