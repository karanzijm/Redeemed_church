<?php $__env->startSection('content'); ?>

<section class="home-slider js-fullheight owl-carousel">
    <div class="slider-item js-fullheight" style="background-image: url('<?php echo e(asset('images/bg_1.jpg')); ?>');">
        <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
            <div class="col-md-8 text-center ftco-animate mt-5">
                <div class="text">
                    <div class="subheading">
                        <span>Christian Church</span>
                    </div>
                  <h1 class="mb-4">Following <span>Jesus</span> wherever we are</h1>
                  <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                  <p><a href="#" class="btn btn-primary py-2 px-4">Be part of us</a> <a href="#" class="btn btn-primary btn-outline-primary py-2 px-4">Read more</a></p>
              </div>
            </div>
          </div>
      </div>
    </div>

    <div class="slider-item js-fullheight" style="background-image: url('<?php echo e(asset('images/bg_2.jpg')); ?>');">
        <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
            <div class="col-md-8 text-center ftco-animate mt-5">
                <div class="text">
                    <div class="subheading">
                        <span>Christian Church</span>
                    </div>
                  <h1 class="mb-4">We <span>Love</span> God, We Believe in God</h1>
                  <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                  <p><a href="#" class="btn btn-primary py-2 px-4">Be part of us</a> <a href="#" class="btn btn-primary btn-outline-primary py-2 px-4">Read more</a></p>
              </div>
            </div>
          </div>
      </div>
    </div>
  </section>

  <section class="ftco-section ftco-no-pt ftco-no-pb ftco-about-section" id="about-section">
    <div class="container-fluid px-0">
        <div class="row d-md-flex text-wrapper">
                <div class="one-half img" style="background-image: url('<?php echo e(asset('images/about.jpg')); ?>');"></div>
                <div class="one-half half-text d-flex justify-content-end align-items-center ftco-animate">
                    <div class="text-inner pl-md-5">
          <h3 class="heading">Welcome to <span>Christian</span> Church</h3>
          <p>Far far away,<strong>creative</strong> behind the word mountains, far from the countries Vokalia and Consonantia, there live the <strong>success</strong> blind texts. Separated they live in Bookmarksgrove</p>
          <p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
          <ul class="my-4">
              <li><span class="ion-ios-checkmark-circle mr-2"></span> Even the all-powerful Pointing</li>
              <li><span class="ion-ios-checkmark-circle mr-2"></span> Behind the word mountains</li>
              <li><span class="ion-ios-checkmark-circle mr-2"></span> Separated they live in Bookmarksgrove</li>
          </ul>
        </div>
                </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-no-pb" id="pastor-section">
  <div class="container">
    <div class="row justify-content-center pb-5">
      <div class="col-md-6 heading-section text-center ftco-animate">
        <span class="subheading">Pastors</span>
        <h2 class="mb-4">Church Pastor</h2>
        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-lg-3 ftco-animate">
        <div class="staff">
          <div class="img-wrap d-flex align-items-stretch">
            <div class="img align-self-stretch" style="background-image: url(images/staff-1.jpg);"></div>
          </div>
          <div class="text d-flex align-items-center pt-3 text-center">
            <div>
              <h3 class="mb-2">Lloyd Wilson</h3>
              <span class="position mb-4">Lead Pastor</span>
              <div class="faded">
                <ul class="ftco-social text-center">
                  <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3 ftco-animate">
        <div class="staff">
          <div class="img-wrap d-flex align-items-stretch">
            <div class="img align-self-stretch" style="background-image: url(images/staff-2.jpg);"></div>
          </div>
          <div class="text d-flex align-items-center pt-3 text-center">
            <div>
              <h3 class="mb-2">Rachel Parker</h3>
              <span class="position mb-4">Lead Pastor</span>
              <div class="faded">
                <ul class="ftco-social text-center">
                  <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3 ftco-animate">
        <div class="staff">
          <div class="img-wrap d-flex align-items-stretch">
            <div class="img align-self-stretch" style="background-image: url(images/staff-3.jpg);"></div>
          </div>
          <div class="text d-flex align-items-center pt-3 text-center">
            <div>
              <h3 class="mb-2">Ian Smith</h3>
              <span class="position mb-4">Lead Pastor</span>
              <div class="faded">
                <ul class="ftco-social text-center">
                  <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3 ftco-animate">
        <div class="staff">
          <div class="img-wrap d-flex align-items-stretch">
            <div class="img align-self-stretch" style="background-image: url(images/staff-4.jpg);"></div>
          </div>
          <div class="text d-flex align-items-center pt-3 text-center">
            <div>
              <h3 class="mb-2">Alicia Henderson</h3>
              <span class="position mb-4">Lead Pastor</span>
              <div class="faded">
                <ul class="ftco-social text-center">
                  <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
                  <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<script>
//   $(document).ready(function(){
// console.log("karanzijm")
//   });
document.addEventListener('DOMContentLoaded', function () {
    // Your jquery code
    console.log("karanzijm");
});
  </script>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('generic.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/generic/home.blade.php ENDPATH**/ ?>