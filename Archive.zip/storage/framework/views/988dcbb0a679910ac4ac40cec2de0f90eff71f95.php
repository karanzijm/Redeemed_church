<head>
    <title>Redeemed Church</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
    <link rel="stylesheet" href="<?php echo e(asset('css/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css/animate.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/css/ionicons.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css/style.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css/bootstrap-datepicker.css')); ?>">
    

</head>
<div class="sidebar" data-image="<?php echo e(asset('light-bootstrap/img/sidebar-5.jpg')); ?>">
    <!--
Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

Tip 2: you can also add an image using data-image tag
-->
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="http://www.creative-tim.com" class="simple-text">
                <?php echo e(__("Creative Tim")); ?>

            </a>
        </div>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link">
                    <i class="nc-icon nc-chart-pie-35"></i>
                    <p><?php echo e(__("Dashboard")); ?></p>
                </a>
            </li>
           
            

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('sendMessage')); ?>">
                    <i class="nc-icon nc-notes"></i>
                    <p><?php echo e(__("Send Message")); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link">
                    <i class="nc-icon nc-paper-2"></i>
                    <p><?php echo e(__("Typography")); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link">
                    <i class="nc-icon nc-atom"></i>
                    <p><?php echo e(__("Icons")); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link">
                    <i class="nc-icon nc-pin-3"></i>
                    <p><?php echo e(__("Maps")); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link">
                    <i class="nc-icon nc-bell-55"></i>
                    <p><?php echo e(__("Notifications")); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /Library/WebServer/Documents/karanxi/resources/views/generic/sidebar.blade.php ENDPATH**/ ?>